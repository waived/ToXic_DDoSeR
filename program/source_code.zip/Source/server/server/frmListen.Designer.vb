﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmListen
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.chkDisplay = New System.Windows.Forms.CheckBox()
        Me.numPort = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.numLimit = New System.Windows.Forms.NumericUpDown()
        Me.btnCtrl = New System.Windows.Forms.Button()
        CType(Me.numPort, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numLimit, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Password"
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(6, 19)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(110, 20)
        Me.txtPassword.TabIndex = 1
        Me.txtPassword.Text = "T0X1C_PWD_1337"
        Me.txtPassword.UseSystemPasswordChar = True
        '
        'chkDisplay
        '
        Me.chkDisplay.AutoSize = True
        Me.chkDisplay.Location = New System.Drawing.Point(6, 38)
        Me.chkDisplay.Name = "chkDisplay"
        Me.chkDisplay.Size = New System.Drawing.Size(60, 17)
        Me.chkDisplay.TabIndex = 2
        Me.chkDisplay.Text = "Display"
        Me.chkDisplay.UseVisualStyleBackColor = True
        '
        'numPort
        '
        Me.numPort.Location = New System.Drawing.Point(122, 19)
        Me.numPort.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.numPort.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numPort.Name = "numPort"
        Me.numPort.Size = New System.Drawing.Size(64, 20)
        Me.numPort.TabIndex = 3
        Me.numPort.Value = New Decimal(New Integer() {13666, 0, 0, 0})
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(119, 3)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(26, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Port"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(189, 3)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Device Limit"
        '
        'numLimit
        '
        Me.numLimit.Location = New System.Drawing.Point(192, 19)
        Me.numLimit.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.numLimit.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numLimit.Name = "numLimit"
        Me.numLimit.Size = New System.Drawing.Size(64, 20)
        Me.numLimit.TabIndex = 5
        Me.numLimit.Value = New Decimal(New Integer() {1000, 0, 0, 0})
        '
        'btnCtrl
        '
        Me.btnCtrl.BackColor = System.Drawing.Color.White
        Me.btnCtrl.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCtrl.Font = New System.Drawing.Font("Microsoft Sans Serif", 5.75!, System.Drawing.FontStyle.Bold)
        Me.btnCtrl.Location = New System.Drawing.Point(262, 19)
        Me.btnCtrl.Margin = New System.Windows.Forms.Padding(0)
        Me.btnCtrl.Name = "btnCtrl"
        Me.btnCtrl.Size = New System.Drawing.Size(54, 18)
        Me.btnCtrl.TabIndex = 7
        Me.btnCtrl.Text = "LISTEN"
        Me.btnCtrl.UseVisualStyleBackColor = False
        '
        'frmListen
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ClientSize = New System.Drawing.Size(322, 57)
        Me.Controls.Add(Me.btnCtrl)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.numLimit)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.numPort)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.chkDisplay)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmListen"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "/// TCP Listener ///"
        Me.TopMost = True
        CType(Me.numPort, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numLimit, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents chkDisplay As CheckBox
    Friend WithEvents numPort As NumericUpDown
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents numLimit As NumericUpDown
    Friend WithEvents btnCtrl As Button
End Class
