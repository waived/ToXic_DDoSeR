﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.zombieQueue = New System.Windows.Forms.DataGridView()
        Me.col_IP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Status = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.zombieMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.tabEnable = New System.Windows.Forms.ToolStripMenuItem()
        Me.tabDisable = New System.Windows.Forms.ToolStripMenuItem()
        Me.tabBuilder = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ucast_Uninstall = New System.Windows.Forms.ToolStripMenuItem()
        Me.ucast_Reconnect = New System.Windows.Forms.ToolStripMenuItem()
        Me.ucast_Disconnect = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.bcast_Uninstall = New System.Windows.Forms.ToolStripMenuItem()
        Me.bcast_Reconnect = New System.Windows.Forms.ToolStripMenuItem()
        Me.bcast_Disconnect = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtHost = New System.Windows.Forms.TextBox()
        Me.numPort = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.comboCommand = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnStart = New System.Windows.Forms.Button()
        Me.btnStop = New System.Windows.Forms.Button()
        Me.comboPower = New System.Windows.Forms.ComboBox()
        CType(Me.zombieQueue, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.zombieMenu.SuspendLayout()
        CType(Me.numPort, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'zombieQueue
        '
        Me.zombieQueue.AllowUserToAddRows = False
        Me.zombieQueue.AllowUserToDeleteRows = False
        Me.zombieQueue.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White
        Me.zombieQueue.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.zombieQueue.BackgroundColor = System.Drawing.Color.White
        Me.zombieQueue.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.zombieQueue.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.zombieQueue.ColumnHeadersHeight = 24
        Me.zombieQueue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.zombieQueue.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_IP, Me.col_Status})
        Me.zombieQueue.ContextMenuStrip = Me.zombieMenu
        Me.zombieQueue.GridColor = System.Drawing.Color.White
        Me.zombieQueue.Location = New System.Drawing.Point(14, 12)
        Me.zombieQueue.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.zombieQueue.MultiSelect = False
        Me.zombieQueue.Name = "zombieQueue"
        Me.zombieQueue.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.zombieQueue.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.zombieQueue.RowHeadersVisible = False
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White
        Me.zombieQueue.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.zombieQueue.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.zombieQueue.ShowCellErrors = False
        Me.zombieQueue.ShowCellToolTips = False
        Me.zombieQueue.ShowEditingIcon = False
        Me.zombieQueue.ShowRowErrors = False
        Me.zombieQueue.Size = New System.Drawing.Size(510, 188)
        Me.zombieQueue.TabIndex = 0
        '
        'col_IP
        '
        Me.col_IP.HeaderText = "IP Address"
        Me.col_IP.Name = "col_IP"
        Me.col_IP.ReadOnly = True
        Me.col_IP.Width = 110
        '
        'col_Status
        '
        Me.col_Status.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.col_Status.HeaderText = "Status"
        Me.col_Status.Name = "col_Status"
        Me.col_Status.ReadOnly = True
        '
        'zombieMenu
        '
        Me.zombieMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.tabBuilder, Me.ToolStripSeparator1, Me.ToolStripMenuItem3})
        Me.zombieMenu.Name = "zombieMenu"
        Me.zombieMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.zombieMenu.Size = New System.Drawing.Size(155, 76)
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tabEnable, Me.tabDisable})
        Me.ToolStripMenuItem1.Image = Global.server.My.Resources.Resources.listen
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(154, 22)
        Me.ToolStripMenuItem1.Text = "TCP Listener"
        '
        'tabEnable
        '
        Me.tabEnable.Image = Global.server.My.Resources.Resources._on
        Me.tabEnable.Name = "tabEnable"
        Me.tabEnable.Size = New System.Drawing.Size(112, 22)
        Me.tabEnable.Text = "Enable"
        '
        'tabDisable
        '
        Me.tabDisable.Enabled = False
        Me.tabDisable.Image = Global.server.My.Resources.Resources.disable
        Me.tabDisable.Name = "tabDisable"
        Me.tabDisable.Size = New System.Drawing.Size(112, 22)
        Me.tabDisable.Text = "Disable"
        '
        'tabBuilder
        '
        Me.tabBuilder.Image = Global.server.My.Resources.Resources.payload
        Me.tabBuilder.Name = "tabBuilder"
        Me.tabBuilder.Size = New System.Drawing.Size(154, 22)
        Me.tabBuilder.Text = "Build Backdoor"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(151, 6)
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2, Me.ToolStripMenuItem4})
        Me.ToolStripMenuItem3.Image = Global.server.My.Resources.Resources.command
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(154, 22)
        Me.ToolStripMenuItem3.Text = "Connection"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ucast_Uninstall, Me.ucast_Reconnect, Me.ucast_Disconnect})
        Me.ToolStripMenuItem2.Image = Global.server.My.Resources.Resources.unicast
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(126, 22)
        Me.ToolStripMenuItem2.Text = "Unicast"
        '
        'ucast_Uninstall
        '
        Me.ucast_Uninstall.Image = Global.server.My.Resources.Resources.uninstall
        Me.ucast_Uninstall.Name = "ucast_Uninstall"
        Me.ucast_Uninstall.Size = New System.Drawing.Size(133, 22)
        Me.ucast_Uninstall.Text = "Uninstall"
        '
        'ucast_Reconnect
        '
        Me.ucast_Reconnect.Image = Global.server.My.Resources.Resources.reconn
        Me.ucast_Reconnect.Name = "ucast_Reconnect"
        Me.ucast_Reconnect.Size = New System.Drawing.Size(133, 22)
        Me.ucast_Reconnect.Text = "Reconnect"
        '
        'ucast_Disconnect
        '
        Me.ucast_Disconnect.Image = Global.server.My.Resources.Resources.socket
        Me.ucast_Disconnect.Name = "ucast_Disconnect"
        Me.ucast_Disconnect.Size = New System.Drawing.Size(133, 22)
        Me.ucast_Disconnect.Text = "Disconnect"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.bcast_Uninstall, Me.bcast_Reconnect, Me.bcast_Disconnect})
        Me.ToolStripMenuItem4.Image = Global.server.My.Resources.Resources.broadcast
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(126, 22)
        Me.ToolStripMenuItem4.Text = "Broadcast"
        '
        'bcast_Uninstall
        '
        Me.bcast_Uninstall.Image = Global.server.My.Resources.Resources.uninstall
        Me.bcast_Uninstall.Name = "bcast_Uninstall"
        Me.bcast_Uninstall.Size = New System.Drawing.Size(133, 22)
        Me.bcast_Uninstall.Text = "Uninstall"
        '
        'bcast_Reconnect
        '
        Me.bcast_Reconnect.Image = Global.server.My.Resources.Resources.reconn
        Me.bcast_Reconnect.Name = "bcast_Reconnect"
        Me.bcast_Reconnect.Size = New System.Drawing.Size(133, 22)
        Me.bcast_Reconnect.Text = "Reconnect"
        '
        'bcast_Disconnect
        '
        Me.bcast_Disconnect.Image = Global.server.My.Resources.Resources.socket
        Me.bcast_Disconnect.Name = "bcast_Disconnect"
        Me.bcast_Disconnect.Size = New System.Drawing.Size(133, 22)
        Me.bcast_Disconnect.Text = "Disconnect"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 203)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Victim"
        '
        'txtHost
        '
        Me.txtHost.Location = New System.Drawing.Point(15, 219)
        Me.txtHost.Name = "txtHost"
        Me.txtHost.Size = New System.Drawing.Size(159, 20)
        Me.txtHost.TabIndex = 2
        '
        'numPort
        '
        Me.numPort.Location = New System.Drawing.Point(180, 219)
        Me.numPort.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.numPort.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numPort.Name = "numPort"
        Me.numPort.Size = New System.Drawing.Size(87, 20)
        Me.numPort.TabIndex = 3
        Me.numPort.Value = New Decimal(New Integer() {80, 0, 0, 0})
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(177, 203)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(30, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Port"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(270, 203)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Power"
        '
        'comboCommand
        '
        Me.comboCommand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboCommand.FormattingEnabled = True
        Me.comboCommand.Items.AddRange(New Object() {"UDP", "TCP", "ICMP", "HTTP", "TLS"})
        Me.comboCommand.Location = New System.Drawing.Point(412, 219)
        Me.comboCommand.Name = "comboCommand"
        Me.comboCommand.Size = New System.Drawing.Size(112, 21)
        Me.comboCommand.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(409, 203)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(61, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Command"
        '
        'btnStart
        '
        Me.btnStart.BackColor = System.Drawing.Color.White
        Me.btnStart.Location = New System.Drawing.Point(15, 245)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(252, 22)
        Me.btnStart.TabIndex = 9
        Me.btnStart.Text = "Send Command"
        Me.btnStart.UseVisualStyleBackColor = False
        '
        'btnStop
        '
        Me.btnStop.BackColor = System.Drawing.Color.White
        Me.btnStop.Enabled = False
        Me.btnStop.Location = New System.Drawing.Point(272, 245)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(252, 22)
        Me.btnStop.TabIndex = 10
        Me.btnStop.Text = "Abort Command"
        Me.btnStop.UseVisualStyleBackColor = False
        '
        'comboPower
        '
        Me.comboPower.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboPower.FormattingEnabled = True
        Me.comboPower.Items.AddRange(New Object() {"Weak", "Moderate", "Strong", "INSANE"})
        Me.comboPower.Location = New System.Drawing.Point(273, 219)
        Me.comboPower.Name = "comboPower"
        Me.comboPower.Size = New System.Drawing.Size(133, 21)
        Me.comboPower.TabIndex = 11
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ClientSize = New System.Drawing.Size(537, 279)
        Me.Controls.Add(Me.comboPower)
        Me.Controls.Add(Me.btnStop)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.comboCommand)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.numPort)
        Me.Controls.Add(Me.txtHost)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.zombieQueue)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ToXic DDoSeR  |  Port: 0  |  Online: 0"
        CType(Me.zombieQueue, System.ComponentModel.ISupportInitialize).EndInit()
        Me.zombieMenu.ResumeLayout(False)
        CType(Me.numPort, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents zombieQueue As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents txtHost As TextBox
    Friend WithEvents numPort As NumericUpDown
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents comboCommand As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents btnStart As Button
    Friend WithEvents btnStop As Button
    Friend WithEvents col_IP As DataGridViewTextBoxColumn
    Friend WithEvents col_Status As DataGridViewTextBoxColumn
    Friend WithEvents zombieMenu As ContextMenuStrip
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents tabBuilder As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents tabEnable As ToolStripMenuItem
    Friend WithEvents tabDisable As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents ucast_Uninstall As ToolStripMenuItem
    Friend WithEvents bcast_Uninstall As ToolStripMenuItem
    Friend WithEvents bcast_Reconnect As ToolStripMenuItem
    Friend WithEvents bcast_Disconnect As ToolStripMenuItem
    Friend WithEvents ucast_Reconnect As ToolStripMenuItem
    Friend WithEvents ucast_Disconnect As ToolStripMenuItem
    Friend WithEvents comboPower As ComboBox
End Class
